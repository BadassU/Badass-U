<!-- hide script from old browsers

$(document).ready(function () {
$('#love').click(function(){ $(".tactics, .truth, .books, .health, .happiness, .work").hide(200); $('.love').show(200);});
$('#tactics').click(function(){ $(".love, .truth, .books, .health, .happiness, .work").hide(200); $('.tactics').show(200);});
$('#truth').click(function(){ $(".tactics, .love, .books, .health, .happiness, .work").hide(200); $('.truth').show(200);});
$('#books').click(function(){ $(".tactics, .truth, .love, .health, .happiness, .work").hide(200); $('.books').show(200);});
$('#health').click(function(){ $(".tactics, .truth, .books, .love, .happiness, .work").hide(200); $('.health').show(200);});
$('#happiness').click(function(){ $(".tactics, .truth, .books, .health, .love, .work").hide(200); $('.happiness').show(200);});
$('#work').click(function(){ $(".tactics, .truth, .books, .health, .love, .happiness").hide(200); $('.work').show(200);});
$('#2019').click(function(){ $(".2018, .2017, .2016, .2015, .2014").hide(200); $('.2019').show(200);});
$('#2018').click(function(){ $(".2019, .2017, .2016, .2015, .2014").hide(200); $('.2018').show(200);});
$('#2017').click(function(){ $(".2019, .2018, .2016, .2015, .2014").hide(200); $('.2017').show(200);});
$('#2016').click(function(){ $(".2019, .2017, .2018, .2015, .2014").hide(200); $('.2016').show(200);});
$('#2015').click(function(){ $(".2019, .2017, .2016, .2018, .2014").hide(200); $('.2015').show(200);});
$('#2014').click(function(){ $(".2019, .2017, .2016, .2015, .2018").hide(200); $('.2014').show(200);});

$('#all').click(function(){ $('.love, .tactics, .truth, .books, .health, .happiness, .work, .2019, .2017, .2016, .2015, .2018').show(200);});
});

// end hiding script from old browsers -->
