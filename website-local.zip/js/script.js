<!-- hide script from old browsers

$(document).ready(function () {

  $('img').removeAttr('title');

  var href = $(location).attr('href');
  var title = $(this).attr('title');

  var next = 0;
  var previous = 0;

  if (document.getElementsByClassName("next")[0].getElementsByTagName( 'a' )[0] != undefined){ next = document.getElementsByClassName("next")[0].getElementsByTagName( 'a' )[0].href;};
  if (document.getElementsByClassName("previous")[0].getElementsByTagName( 'a' )[0] != undefined){ previous = document.getElementsByClassName("previous")[0].getElementsByTagName( 'a' )[0].href;};
 
  $("body").keydown(function(e) {
  if(e.keyCode == 37 && previous != 0) { // left
    window.location = previous;
  }
  else if(e.keyCode == 39 && next != 0) { // right
    window.location = next;
  }
  });
  
 if( /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ) {
 // some code..
  $("h1").swipe( {
    swipeLeft:function(event, direction) {
      if (next != 0){window.location = next;};
    },
    threshold:100, allowPageScroll:"vertical"
  });

  $("h1").swipe( {
    swipeRight:function(event, direction) {
      if (previous != 0){window.location = previous;};
    },
    threshold:100, allowPageScroll:"vertical"
  });
 }
 
 $('a').each(function() {
   var a = new RegExp('/' + window.location.host + '/');
   if(!a.test(this.href)) {
       $(this).click(function(event) {
           event.preventDefault();
           event.stopPropagation();
           window.open(this.href, '_blank');
       });
   }
 });

});

// end hiding script from old browsers -->